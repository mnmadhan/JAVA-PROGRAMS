public class Q1_TryCatch {
    public static void main(String[] args) {
        try {
            int a = 5/0;
        } catch (ArithmeticException e) {
            System.out.println("Cannot divide by zero");
        }
    }
}