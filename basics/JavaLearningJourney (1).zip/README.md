# Java Learning Journey

This repository tracks consistent Java learning with structured folders by topic.

## Topics Covered
- 01 Basics
- 02 IfElse Switch
- 03 Loops
- 04 Arrays
- 05 Strings
- 06 Functions
- 07 OOP Basics
- 08 Inheritance
- 09 ExceptionHandling
- 10 Collections
