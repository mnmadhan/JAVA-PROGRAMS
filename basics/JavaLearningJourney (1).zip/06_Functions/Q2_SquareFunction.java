public class Q2_SquareFunction {
    public static int square(int x) {
        return x * x;
    }
    public static void main(String[] args) {
        System.out.println(square(5));
    }
}