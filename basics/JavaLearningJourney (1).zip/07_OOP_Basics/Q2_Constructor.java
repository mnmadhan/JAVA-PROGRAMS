class Car {
    String model;
    Car(String m) { model = m; }
}
public class Q2_Constructor {
    public static void main(String[] args) {
        Car c = new Car("Swift");
        System.out.println(c.model);
    }
}