class Student {
    String name = "Madhan";
    int age = 20;
}
public class Q1_ClassExample {
    public static void main(String[] args) {
        Student s = new Student();
        System.out.println(s.name + " " + s.age);
    }
}