public class Q2_Length {
    public static void main(String[] args) {
        String s = "Java";
        System.out.println("Length: " + s.length());
    }
}