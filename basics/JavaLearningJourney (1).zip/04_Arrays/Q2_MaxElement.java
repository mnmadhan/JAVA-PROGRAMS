public class Q2_MaxElement {
    public static void main(String[] args) {
        int[] arr = {1, 5, 3};
        int max = arr[0];
        for (int i : arr) if (i > max) max = i;
        System.out.println("Max: " + max);
    }
}