public class Q1_PrintArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3};
        for (int i : arr) System.out.println(i);
    }
}