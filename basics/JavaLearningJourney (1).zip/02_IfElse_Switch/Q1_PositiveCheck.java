public class Q1_PositiveCheck {
    public static void main(String[] args) {
        int num = -5;
        if (num > 0) System.out.println("Positive");
        else System.out.println("Non-positive");
    }
}