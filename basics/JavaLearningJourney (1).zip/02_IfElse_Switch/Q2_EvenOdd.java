public class Q2_EvenOdd {
    public static void main(String[] args) {
        int n = 4;
        if (n % 2 == 0) System.out.println("Even");
        else System.out.println("Odd");
    }
}