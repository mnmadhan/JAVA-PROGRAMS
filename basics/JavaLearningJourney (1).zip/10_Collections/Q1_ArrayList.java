import java.util.*;
public class Q1_ArrayList {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("Java");
        list.add("Python");
        for (String lang : list)
            System.out.println(lang);
    }
}