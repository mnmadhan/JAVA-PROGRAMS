public class Q2_Variables {
    public static void main(String[] args) {
        int age = 20;
        System.out.println("Age: " + age);
    }
}